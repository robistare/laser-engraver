Thank you for downloading the files!
The file format is for Lightburn software https://lightburnsoftware.com/
and it will not work in other programs since the Ligthburn uses an unique shape properties 
that make this kind of test pattern even possible.
You can register a free 30 day, non binding, fully featured trial to test it out.
I am not affiliated with Lightburn. I use it because it is the best software that saves you a lot of time.

Enjoy!

Regards,
HLC